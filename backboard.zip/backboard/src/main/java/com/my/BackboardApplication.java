package com.my;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackboardApplication.class, args);
	}

}
