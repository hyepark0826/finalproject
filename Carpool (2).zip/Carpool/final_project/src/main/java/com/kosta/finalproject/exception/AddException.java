package com.kosta.finalproject.exception;

public class AddException extends Exception {
	public AddException() {
		super();
	}

	public AddException(String message) {
		super(message);
	}

	
}
