package com.kosta.finalproject.exception;

public class ModifyException extends Exception {
	public ModifyException() {
		super();
	}

	public ModifyException(String message) {
		super(message);
	}

	
}
