package com.kosta.finalproject.exception;

public class FindException extends Exception {
	public FindException() {
		super();
	}

	public FindException(String message) {
		super(message);
	}

	
}
