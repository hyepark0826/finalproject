package com.kosta.finalproject.controller;


import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

//뷰와 모델의 다리역할, 뷰로부터 사용자의 인터랙션을 받아 모델에 전달하고, 
//바뀐 모델 데이터를 뷰에 다시 전달하여 업데이트함

@Slf4j
@Controller
@RequestMapping("/notice")
public class NoticeController {
	

	@Value("${file.upload.directory}")
	private String fileUploadPath;
	
	//공지사항 목록
	@GetMapping("/noticeList")
	public String noticeList() {
		log.info("공지사항 목록 이동");
		return "notice/noticeList";
		
	}

	//공지사항 등록폼
	@GetMapping("/noticeWrite")
	public String noticeWrite() {
		log.info("공지사항 작성 페이지 이동");
		return "notice/noticeWrite";
		
	}	

	//공지사항 상세보기
	@GetMapping("/noticeDetail")
	public String noticeDetail() {
		log.info("공지사항 상세 페이지 이동");
		return "notice/noticeDetail";
		
	}	
	
	@GetMapping("/saveNotice")
	public void saveNotice(HttpServletRequest request) {
		
    	//log.info("Controller @PostMapping(/saveNotice) 화면에서 넘어온 Dto의 값 : "+bbsDto.toString());
    	//log.info(":::::application.properties 선언한 파일업로드 경로 fileUploadPath >>>>>>>>> "+fileUploadPath);
    	
		log.info("fileUploadPath :::::: : "+fileUploadPath.toString());
		
    	//1-1. 게시글번호 생성 (※게시판저장 및 파일저장의 사용)
    	//final String getSelectBno = bbsService.selectBno();
    	
    	//1-2. bbsDto에 생성한 게시글번호를 넣는다.
    	//bbsDto.setBno(getSelectBno);

		//try {
			//1-3. 마이바티스에서는 insert문이 성공하면 숫자 1을 반환합니다.
			//if(bbsService.insertBbs(bbsDto) > 0) {
				//if(filesService.fileUpload(bbsDto.getUpFile(), getSelectBno, fileUploadPath, bbsDto.getDeleteFilesNo())) {
				//ok
				//}else {
				//fail
				//}
				
			//}else {
				//fail
			//}
		//} catch (Exception e) {
			//fail
			// TODO Auto-generated catch block
			//e.printStackTrace();
		//}   
			
	}
}